<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G-Plans WM Intake Parser</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 700px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            background: white;
        }
        textarea {
            width: 100%;
            height: 300px;
            font-size: 16px;
            padding: 10px;
            margin-bottom: 10px;
            resize: none;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .output {
            margin-top: 20px;
            font-size: 16px;
            color: black;
            text-align: left;
        }
        .warning {
            color: red;
            font-weight: bold;
        }
        .med-allergy-warning {
            color: red;
            font-weight: bold;
        }
        .address-warning {
            color: red;
            font-weight: bold;
        }
        .note {
            color: blue;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>G-Plans WM Intake Parser</h2>
    <p>Paste the intake information below to parse the data:</p>

    <!-- Textarea to paste the block of text -->
    <textarea id="inputText" placeholder="Paste the intake information here..."></textarea><br>
    
    <button id="parseButton" onclick="parseText()">Generate Output</button>

    <!-- Output section -->
    <div id="output" class="output"></div>
</div>

<script>
    function parseText() {
        const inputText = document.getElementById('inputText').value;

        // Regular expressions to extract values from the pasted text
        const regex = {
            dob: /Date of Birth\s*(\d{4}-\d{2}-\d{2})/,
            address1: /Address\s*Line 1\s*(.*)/,
            address2: /Line 2\s*(.*)/,
            state: /State\s*(\w{2})/,
            city: /City\s*(\w+)/,
            country: /Country\s*(\w+)/,
            zip: /Zip\s*(\d{5})/,
            bmi: /BMI\s*(\d+\.\d)/,
            height_ft: /Height \(ft.\)\s*(\d+)/,
            height_in: /Height \(in.\)\s*(\d+)/,
            weight: /Weight \(lbs.\)\s*(\d+)/,
            goal_weight: /Goal weight\.\s*(\d+)/,
            phone: /Phone\s*(\+?\d+)/,
            gender: /Gender\s*(\w+)/,
            medication_allergies: /Do you have any medication allergies\?\s*(Yes|No)/,
            medication_allergy_list: /If yes, list your medication allergies\.\s*(.*)/,
            weight_loss_medication: /Have you taken any prescription medications to lose weight before\?\s*(Yes|No)/,
            bariatric_surgery: /Have you had bariatric \(weight loss\) surgery before\?\s*(Yes|No)/,
            previous_weight_loss_attempt: /Have you ever attempted to lose weight in a weight management program\s*\?\s*(Yes|No)/,
            physical_activity: /Are you willing to:\s*Increase your physical activity/,
            caloric_intake: /Reduce your caloric intake/,
            weight_change: /How has your weight changed in the last 12 months\?\s*(.*)/,
            diabetes: /Have you been diagnosed with prediabetes or type 2 diabetes\?\s*(Yes|No)/,
            blood_pressure: /What is your current or average blood pressure range\?\s*(.*)/,
            heart_rate: /What is your current or average resting heart rate range\?\s*(.*)/,
            shipping_address: /Please list shipping address \(No PO boxes\)\s*(.*)/,
        };

        // Extracting values using regex
        const extracted = {};
        for (let key in regex) {
            const match = inputText.match(regex[key]);
            extracted[key] = match ? match[1] : 'Not provided';
        }

        // Generate the output
        let output = ` 
            <h3>Parsed Data</h3>
            <p><strong>BMI:</strong> ${extracted.bmi}</p>
            <p><strong>Goal Weight:</strong> ${extracted.goal_weight}</p>
            <p><strong>Shipping Address:</strong> ${extracted.shipping_address}</p>
        `;

        // Check if PO Box or PO Boxes are present in shipping address (case-insensitive)
        const address = extracted.shipping_address.toLowerCase();
        if (address.includes("po box") || address.includes("po boxes")) {
            output += ` 
                <div class="address-warning">
                    <strong>Warning:</strong> PO Box detected in the shipping address. Please note:
                    <ul>
                        <li>Sent to Tier 2</li>
                        <li>Copy ticket number</li>
                        <li>Unassign</li>
                    </ul>
                </div>
            `;
        }

        // Address and Shipping Address mismatch warning
        const fullAddress = `${extracted.address1}, ${extracted.address2}, ${extracted.city}, ${extracted.state}, ${extracted.country} ${extracted.zip}`.toLowerCase();
        if (fullAddress !== extracted.shipping_address.toLowerCase()) {
            output += `
                <div class="address-warning">
                    <strong>Warning:</strong> The Address and Shipping Address do not match!
                </div>
            `;
        }
        
        // Handling Medication Allergies
        if (extracted.medication_allergies === 'Yes') {
            if (extracted.medication_allergy_list && extracted.medication_allergy_list !== 'Not provided') {
                // If allergy details are provided, append them to the provider's note
                output += ` 
                    <p class="med-allergy-warning"><strong>Medication Allergies:</strong> ${extracted.medication_allergy_list}</p>
                    <p class="note"><strong>For Provider's note:</strong> Patient has listed the following allergies: ${extracted.medication_allergy_list}</p>
                `;
            } else {
                // If allergy details are blank, add the appropriate note
                output += ` 
                    <p class="med-allergy-warning"><strong>Medication Allergies:</strong> Yes, but no allergies listed.</p>
                    <p class="note"><strong>For Provider's note:</strong> Patient said 'Yes' on having medication allergies but did not list them on intake.</p>
                `;
            }
        } else {
            output += `<p><strong>Medication Allergies:</strong> No allergies reported.</p>`;
        }

        // Handling Weight Loss Medication Question
        if (extracted.weight_loss_medication === 'Yes') {
            output += `<p><strong>Weight Loss Medication:</strong> Yes</p>`;
            output += `<p class="note"><strong>For Provider's note:</strong> Patient has taken prescription medications to lose weight before.</p>`;
        } else {
            output += `<p><strong>Weight Loss Medication:</strong> No action required</p>`;
        }

        // Check for GLP1 medication or mention in the entire input text
        if (inputText.toLowerCase().includes("glp1")) {
            output += `<p class="note"><strong>Note:</strong> GLP1 medication detected in the intake information.</p>`;
        }

        // Display output
        document.getElementById('output').innerHTML = output;

        // Change button to redirect to DOSESPOT.PHP
        const parseButton = document.getElementById('parseButton');
        parseButton.innerHTML = 'Go to DOSESPOT.PHP';
        parseButton.onclick = function() {
            window.location.href = 'DOSESPOT.PHP'; // Redirect to DOSESPOT.PHP
        };
    }
</script>

</body>
</html>
