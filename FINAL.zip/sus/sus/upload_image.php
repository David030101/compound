<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle image upload via Base64
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['image_data'])) {
    // Get the Base64 encoded image string from the POST request
    $imageBase64 = $_POST['image_data'];

    // Check if the Base64 string has the 'data:image' prefix and remove it
    if (preg_match('/^data:image\/(\w+);base64,/', $imageBase64, $type)) {
        // Remove the Base64 prefix
        $imageBase64 = substr($imageBase64, strpos($imageBase64, ',') + 1);
        
        // Decode the Base64 string into binary data
        $imageData = base64_decode($imageBase64);

        // Check if the Base64 string is valid and can be decoded
        if ($imageData === false) {
            echo "Base64 decoding failed!";
            exit;
        }

        // Generate a unique name for the image
        $imageName = "image_" . time() . "." . $type[1]; // Example: image_1635427631.jpg

        // Prepare the SQL statement to insert image data into the database
        $stmt = $conn->prepare("INSERT INTO images (image_data, image_name) VALUES (?, ?)");
        $stmt->bind_param("ss", $imageData, $imageName);

        // Execute the query
        if ($stmt->execute()) {
            echo "Image uploaded and stored successfully: " . $imageName . "<br>";
        } else {
            echo "Error uploading image: " . $stmt->error . "<br>";
        }

        $stmt->close();
    } else {
        echo "Invalid Base64 image data!";
    }
}

$conn->close();
?>
