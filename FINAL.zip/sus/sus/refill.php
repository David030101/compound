<?php  
session_start();
date_default_timezone_set('UTC'); // Set timezone

$error = ""; // Store error message

// Preserve previously entered values
$input_date = $_POST['input_date'] ?? "";
$appointment_date = $_POST['appointment_date'] ?? "";
$previous_date = $_POST['previous_date'] ?? "";

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['input_date']) && isset($_POST['appointment_date']) && isset($_POST['previous_date'])) {
    $input_date = $_POST['input_date']; // Manual Date
    $appointment_date = $_POST['appointment_date']; // Appointment Date
    $previous_date = $_POST['previous_date']; // Previous Date

    $current_date = date('Y-m-d');  
    $min_previous_date = date('Y-m-d', strtotime('-89 days')); // Previous date should not be older than 89 days
    $min_input_date = date('Y-m-d', strtotime('-29 days')); // Input date should be within last 29 days
    $max_appointment_date = date('Y-m-d', strtotime("$input_date +29 days")); // Appointment date must be within 29 days of input_date

    // VALIDATION CHECKS
    if ($previous_date < $min_previous_date) {
        $error = "VOID: The previous date cannot be older than 89 days!";
    } elseif ($input_date > $current_date) {
        $error = "VOID: The entered manual date cannot be in the future!";
    } elseif ($input_date < $min_input_date) {
        $error = "VOID: The entered manual date cannot be older than 29 days!";
    } elseif ($appointment_date < $input_date) {
        $error = "VOID: The appointment date cannot be before the manual date!";
    } elseif ($appointment_date > $max_appointment_date) {
        $error = "VOID: The appointment date cannot be more than 29 days after the manual date!";
    }

    // IF NO ERRORS, PROCEED
    if (!$error) {
        $_SESSION['manual_date'] = $input_date;
        $_SESSION['appointment_date'] = $appointment_date;
        $_SESSION['previous_date'] = $previous_date;

        header("Location: IP.php"); // Redirect to the next page
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Dates</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            background: white;
        }
        input[type="date"], button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Enter Dates</h2>
    
    <?php if (!empty($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    
    <form method="POST">
    <label for="input_date">refill Intake Date (Today or Last 29 Days):</label>
    <input type="date" name="input_date" value="<?= htmlspecialchars($input_date) ?>" required>

        <label for="previous_date">Patient medication Informaton date (Not older than 89 days):</label>
        <input type="date" name="previous_date" value="<?= htmlspecialchars($previous_date) ?>" required>

        

        <label for="appointment_date">Appointment Date (Manual Date + 29 Days):</label>
        <input type="date" name="appointment_date" value="<?= htmlspecialchars($appointment_date) ?>" required>

        <button type="submit">Submit</button>
    </form>
</div>

</body>
</html>
