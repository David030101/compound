<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPLANS</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">

    <div class="bg-white p-8 rounded-lg shadow-lg max-w-sm text-center">
    <h1 class="text-2xl font-bold text-gray-700 mb-4">Choose an Option</h1>
        <p class="text-gray-500 mb-6">Select whether you want to proceed with a refill or an initial setup.</p>
      
    <div class="flex flex-col space-y-4">
    <a href="initial.php" class="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-md text-lg transition">Initial Visit</a>
            <a href="r.php" class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-md text-lg transition">Refill Visit</a>
            
        </div>
      
    </div>
</body>
</html>
