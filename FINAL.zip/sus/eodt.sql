CREATE TABLE trash (
    id INT PRIMARY KEY AUTO_INCREMENT,
    number1 VARCHAR(255),
    number2 VARCHAR(255),
    text_input TEXT,
    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
