<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Full Screen Text Viewer</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
    }

    textarea {
      width: 100%;
      height: 200px;
      font-size: 16px;
    }

    button {
      margin-top: 10px;
      padding: 10px 20px;
      font-size: 16px;
    }

    #fullscreenViewer {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: #f8f9fa;
      color: #212529;
      padding: 40px;
      box-sizing: border-box;
      overflow-y: auto;
      display: none;
      z-index: 9999;
    }

    #closeViewer {
      position: absolute;
      top: 20px;
      right: 20px;
      font-size: 20px;
      cursor: pointer;
      background: none;
      border: none;
      color: #000;
    }

    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
      font-size: 18px;
    }

    .highlight-red {
      color: red;
      font-weight: bold;
    }

    .highlight-blue {
      color: blue;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <h2>Paste your text below</h2>
  <textarea id="inputText" placeholder="Paste your content here..."></textarea>
  <br>
  <button onclick="viewFullScreen()">View Full Screen</button>

  <div id="fullscreenViewer">
    <button id="closeViewer" onclick="closeViewer()">✖</button>
    <pre id="outputText"></pre>
  </div>

  <script>
    function highlightText(text) {
      const medicationStart = "Are you currently taking any medications or supplements (over-the-counter prescription)?\nYes";
      const allergyStart = "Do you have any medication allergies?";

      // Check if 'Yes' is mentioned and find the range to highlight
      if (text.includes(medicationStart) && text.includes(allergyStart)) {
        const startIdx = text.indexOf(medicationStart) + medicationStart.length;
        const endIdx = text.indexOf(allergyStart);

        const beforeText = text.substring(0, startIdx);  // Text before the red section
        const redText = text.substring(startIdx, endIdx).trim();  // Text to be highlighted red
        const afterText = text.substring(endIdx);  // Text after the red section

        // Wrap the redText in <span> tags to apply the red highlight
        const highlightedText = beforeText + "<span class='highlight-red'>" + redText + "</span>" + afterText;
        return highlightedText;
      }

      return text;  // Return the text as is if conditions aren't met
    }

    function viewFullScreen() {
      const input = document.getElementById('inputText').value;
      const highlighted = highlightText(input);
      document.getElementById('outputText').innerHTML = highlighted;
      document.getElementById('fullscreenViewer').style.display = 'block';
    }

    function closeViewer() {
      document.getElementById('fullscreenViewer').style.display = 'none';
    }
  </script>

</body>
</html>
