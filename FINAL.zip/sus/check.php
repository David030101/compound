<!DOCTYPE html>
<html>
<head>
    <title>Checklist - Initial & Refill</title>
    <style>
        .checklist-section {
            display: none;
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .checklist-section label {
            display: block;
            margin: 5px 0;
        }

        .form-container {
            width: 400px;
            margin: auto;
            padding-top: 40px;
        }
    </style>
    <script>
        function toggleChecklist() {
            var option = document.getElementById("type").value;
            document.getElementById("initial").style.display = option === "initial" ? "block" : "none";
            document.getElementById("refill").style.display = option === "refill" ? "block" : "none";
        }
    </script>
</head>
<body>
<div class="form-container">
    <h2>Checklist</h2>
    <label for="type">Select Type:</label>
    <select id="type" name="type" onchange="toggleChecklist()" required>
        <option value="">-- Choose --</option>
        <option value="initial">Initial</option>
        <option value="refill">Refill</option>
    </select>

    <!-- INITIAL CHECKLIST -->
    <div id="initial" class="checklist-section">
        <h3>Initial Checklist</h3>
        <label><input type="checkbox" name="correct_date"> Correct Date</label>
        <label><input type="checkbox" name="cma"> CMA</label>
        <label><input type="checkbox" name="med_dose_spot"> Medicine in Dose Spot</label>
        <label><input type="checkbox" name="meds_intake"> Meds in Intake</label>
        <label><input type="checkbox" name="hpi_section"> HPI Section Completed</label>
        <label><input type="checkbox" name="medical_section_select"> Medical Section Selected</label>
        <label><input type="checkbox" name="medical_section_input"> Medical Section Input Filled</label>
    </div>

    <!-- REFILL CHECKLIST -->
    <div id="refill" class="checklist-section">
        <h3>Refill Checklist</h3>
        <label><input type="checkbox" name="last_deliver"> Check Last Delivery</label>
        <label><input type="checkbox" name="intake_refill"> Check Intake Refill</label>
        <label><input type="checkbox" name="cma_appt"> Check CMA in Appointment Date</label>
        <label><input type="checkbox" name="dose_spot"> Check Dose Spot</label>
        <label><input type="checkbox" name="current_weight"> Check Current Weight</label>
        <label><input type="checkbox" name="prev_weight"> Check Previous Weight</label>
        <label><input type="checkbox" name="labs"> Check Labs</label>
        <label><input type="checkbox" name="requested_meds"> Requested Meds</label>
    </div>

    <br>
    <button type="submit">Submit Checklist</button>
</div>
</body>
</html>
