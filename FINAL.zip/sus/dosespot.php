<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medication Expiration Checker</title>
    <form action="IP.php" method="GET">
        <input type="submit" value="Done and Go to Initial" />
    </form>
<style>
        /* Style for displaying the three boxes (left, center, right) */
        .container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .medication-box {
            border: 1px solid #ccc;
            padding: 10px;
            width: 30%;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .medication-box h3 {
            text-align: center;
        }
    </style>
       <style>
        /* Style the button */
        .submit-button {
            background-color: green; /* Green background */
            color: white; /* White text */
            border: 2px solid navy; /* Navy blue border */
            padding: 10px 20px; /* Padding around the text */
            font-size: 16px; /* Font size */
            cursor: pointer; /* Pointer cursor on hover */
            border-radius: 5px; /* Rounded corners */
            text-align: center; /* Center the text */
            display: inline-block; /* Makes it behave like a button */
            text-decoration: none; /* Remove underline */
        }
        
        /* Button hover effect */
        .submit-button:hover {
            background-color: darkgreen; /* Darker green when hovered */
            border-color: darkblue; /* Darker blue border */
        }
    </style>
</head>
<body>
    <h2>Medication Expiration Checker</h2>
    
    <!-- Form to paste medication data -->
    <form action="" method="POST">
        <textarea name="medication_data" rows="10" cols="50" placeholder="Paste medication data here..."></textarea><br><br>
        <input type="submit" value="Check Expiration">
    </form>

    <?php
    // Check if the form is submitted and contains medication data
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['medication_data'])) {
        // Get the pasted medication data from the textarea
        $medication_data = $_POST['medication_data'];

        // Process the pasted data and check expiration
        $medications = processMedicationData($medication_data);
        $current_date = new DateTime(); // Today's date

        // Separate medications into expired and non-expired
        $expired_meds = [];
        $active_meds = [];
        $medication_names = [];

        // Loop through the medications to check expiration
        foreach ($medications as $medication) {
            $expired = isExpired($medication, $current_date);

            // Create a unique key based on normalized name and dosage
            $unique_key = generateUniqueKey($medication['name'], $medication['dose']);
            
            if ($expired) {
                $expired_meds[$medication['name']] = $medication;
            } else {
                // Match medications with the same active ingredient and dosage
                if (!isset($medication_names[$unique_key])) {
                    $active_meds[$medication['name']] = $medication;
                    $medication_names[$unique_key] = true; // Mark this combination as seen
                }
            }
        }

        // Display containers
        echo "<div class='container'>";

        // Left Box: Expired Medications
        echo "<div class='medication-box'>";
        echo "<h3>Expired Medications</h3>";
        if (!empty($expired_meds)) {
            // Loop through expired medications and display their details
            foreach ($expired_meds as $medication) {
                echo "<strong>Medication Name:</strong> " . htmlspecialchars($medication['name']) . "<br>";
                echo "<strong>Supply:</strong> " . $medication['supply_duration'] . " days<br>";
                echo "<strong>Last Fill Date:</strong> " . $medication['last_fill_date'] . "<br><br>";
            }
        } else {
            echo "<p>No expired medications.</p>"; // No expired medications
        }
        echo "</div>";

        // Center Box: Active Medications (Only Name and Dosage)
        echo "<div class='medication-box'>";
        echo "<h3>Active Medications</h3>";
        if (!empty($active_meds)) {
            // Loop through active medications and display only name and dosage
            foreach ($active_meds as $medication) {
                echo htmlspecialchars($medication['name']) . ", ";
  }
        } else {
            echo "<p>No active medications.</p>"; // No active medications
        }
        echo "</div>";
// Right Box: Alphabetically Sorted Non-Expired Medications (Names Only)
echo "<div class='medication-box'>";
echo "<h3>Medications Alphabetically (Non-Expired)</h3>";

if (!empty($active_meds)) {
    // Alphabetically sort the active meds by medication name
    ksort($active_meds);

    // Loop through sorted medication names and display them individually
    foreach ($active_meds as $medication) {
        // Remove numbers and 'mg' from the medication name
        $medication_name = htmlspecialchars($medication['name']);
        $medication_name = preg_replace('/\d+/', '', $medication_name);  // Remove numbers
        $medication_name = str_ireplace('mg', '', $medication_name);      // Remove 'mg' case-insensitively

        // Display the medication name with a copy button
        echo "<strong>Medication Name:</strong> " . $medication_name . " ";
        echo "<button onclick=\"copyToClipboard('$medication_name')\">Copy</button><br>";
    }
} else {
    echo "<p>No non-expired medications.</p>"; // No non-expired medications
}

echo "</div>"; // End of medication box

// Add JavaScript for the copy functionality
echo "<script>
function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
}
</script>";

// If no medications are found, show a message
if (empty($medications)) {
    echo "<p>No valid medication data found. Please check your input format.</p>";
}

    }

    // Function to process the pasted medication data
    function processMedicationData($data) {
        // Split the pasted data by line breaks
        $lines = explode("\n", $data);
        $medications = [];
        $name = "";
        $dose = "";
        $supply_duration = "";
        $last_fill_date = "";

        // Loop through each line of data
        foreach ($lines as $line) {
            $line = trim($line);

            // Skip empty lines
            if (empty($line)) continue;

            // Identify the medication name (looks for 'MG', 'MCG', 'DS', etc. as part of the dosage)
            if (preg_match('/\b(\d+\s*(MG|MCG|G|DS|ML|IU))\b/i', $line, $matches)) {
                $dose = strtoupper(trim($matches[0])); // Normalize to uppercase and trim spaces
                if (!empty($name)) {
                    // Add the previously identified medication to the list
                    $medications[$name] = [
                        'name' => $name,
                        'dose' => $dose, // Add dose to the medication
                        'supply_duration' => (int)$supply_duration,
                        'last_fill_date' => formatDate($last_fill_date)
                    ];
                }
                $name = strtoupper(trim($line)); // Set new medication data, normalized to uppercase
            }

            // Check for supply info and last fill date
            if (strpos($line, 'Supply of') !== false && strpos($line, 'days') !== false) {
                // Split the line to extract supply duration and last fill date
                $parts = preg_split('/\s{2,}|\t/', trim($line));

                // Extract the supply duration (only the first number before "days")
                $supply_duration = extractSupplyDuration($parts[0]);

                // Last part is the last fill date
                $last_fill_date = end($parts);
            }
        }

        // Add the last medication to the list (if any)
        if (!empty($name)) {
            $medications[$name] = [
                'name' => $name,
                'dose' => $dose, // Include dose in the last medication
                'supply_duration' => (int)$supply_duration,
                'last_fill_date' => formatDate($last_fill_date)
            ];
        }

        return $medications;
    }

    // Function to format the date to 'Y-m-d'
    function formatDate($date_str) {
        $date = DateTime::createFromFormat('M d, Y', $date_str);
        return $date ? $date->format('Y-m-d') : $date_str; // Return formatted date or the original string
    }

    // Function to extract the supply duration in days (e.g., "Supply of 40 days" -> 40)
    function extractSupplyDuration($supply_info) {
        preg_match('/\d+/', $supply_info, $matches); // Extract the first numeric value before "days"
        return $matches[0] ?? 0; // Return the first number (days), default to 0 if not found
    }

    // Function to check if the medication is expired based on the "Supply of X days"
    function isExpired($medication, $current_date) {
        $last_fill_date = new DateTime($medication['last_fill_date']); // Convert the last fill date to DateTime object
        $expiration_date = $last_fill_date->modify('+' . $medication['supply_duration'] . ' days'); // Add supply days to last fill date
        
        // Compare the expiration date with the current date
        return $current_date > $expiration_date; // Return true if the current date is later than expiration date
    }

    // Function to generate a unique key for each medication based on name and dose
    function generateUniqueKey($name, $dose) {
        $name = strtolower(trim($name)); // Normalize the name
        $dose = strtolower(trim($dose)); // Normalize the dose
        $name_parts = explode(" ", $name); // Split name into parts
        $dose_parts = explode(" ", $dose); // Split dose into parts

        // Only match based on main medication name and dosage
        $main_name = $name_parts[0]; // Use the first part of the name as the key
        $main_dose = $dose_parts[0]; // Use the first part of the dose

        return $main_name . "-" . $main_dose; // Return the unique key
    }
    ?>
</body>
</html>
