<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eod"; // Change this to your actual DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["number1"], $_POST["number2"], $_POST["text_input"], $_POST["status_text"])) {
        $number1 = filter_var($_POST["number1"], FILTER_VALIDATE_INT);
        $number2 = filter_var($_POST["number2"], FILTER_VALIDATE_INT);
        $text_input = htmlspecialchars(trim($_POST["text_input"]));
        $status_text = htmlspecialchars(trim($_POST["status_text"]));

        if ($number1 !== false && $number2 !== false && !empty($text_input) && !empty($status_text)) {
            $stmt = $conn->prepare("INSERT INTO my_table (number1, number2, text_input, status_text) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $number1, $number2, $text_input, $status_text);

            if ($stmt->execute()) {
                $message = "<div class='success-message'>Data inserted successfully!</div>";
            } else {
                $message = "<div class='error-message'>Error: " . $stmt->error . "</div>";
            }

            $stmt->close();
        } else {
            $message = "<div class='error-message'>Invalid input. Please check your entries.</div>";
        }
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submission</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            padding: 50px;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            margin: auto;
        }
        label {
            font-weight: bold;
        }
        input[type="number"],
        input[type="text"],
        select {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            width: 100%;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .success-message {
            color: green;
            text-align: center;
            margin-top: 20px;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Form -->
    <form method="post" action="">
        <label for="number1">Number 1:</label>
        <input type="number" name="number1" id="number1" required><br>

        <label for="number2">Number 2:</label>
        <input type="number" name="number2" id="number2" required><br>

        <label for="text_input">Text Input:</label>
        <input type="text" name="text_input" id="text_input" required><br>

        <label for="status_text">Status:</label>
        <select name="status_text" id="status_text" required>
            <option value="">-- Select Status --</option>
            <option value="Initial">Initial</option>
            <option value="Refill">Refill</option>
            <option value="Sent to Tier 2">Sent to Tier 2</option>
        </select><br>

        <input type="submit" value="Submit">
    </form>

    <!-- Message Display -->
    <?php if (isset($message)) echo $message; ?>
</body>
</html>
