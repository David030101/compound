<?php
// Database connection details
$servername = "localhost"; // Change to your server name
$username = "root"; // Change to your database username
$password = ""; // Change to your database password
$dbname = "gplans"; // Change to your database name

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = ""; // To store any error messages
$success = ""; // To store success message

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the ticket number from the form
    if (isset($_POST['ticket_number']) && !empty($_POST['ticket_number'])) {
        $ticket_number = $_POST['ticket_number'];
    } else {
        $error = "Please provide a ticket number.";
    }

    // Process the image data (base64)
    if (isset($_POST['image_data']) && !empty($_POST['image_data'])) {
        $image_data = $_POST['image_data'];  // base64 encoded image

        // Prepare SQL to insert ticket number and image data into the database
        $stmt = $conn->prepare("INSERT INTO tickets (ticket_number, image_data) VALUES (?, ?)");
        $stmt->bind_param("ss", $ticket_number, $image_data);

        // Execute the query
        if ($stmt->execute()) {
            $success = "Ticket number and images have been saved successfully!";
        } else {
            $error = "Error saving ticket and images: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        $error = "Please paste the image data in the textboxes.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Save Ticket and Images</title>
</head>
<body>
    <h2>Save Ticket Number and Images</h2>

    <!-- Display success/error message -->
    <?php if ($success): ?>
        <p style="color: green;"><?php echo $success; ?></p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- Form to upload ticket number and images -->
    <form action="" method="POST">
        <label for="ticket_number">Ticket Number:</label>
        <input type="text" name="ticket_number" id="ticket_number" required><br><br>

        <label for="image_data[]">Paste Image Data (Base64):</label><br>
        <textarea name="image_data[]" rows="4" cols="50" placeholder="Paste base64 image here..." required></textarea><br><br>

        <!-- Add more image data textboxes -->
        <textarea name="image_data[]" rows="4" cols="50" placeholder="Paste another base64 image here..."></textarea><br><br>
        <textarea name="image_data[]" rows="4" cols="50" placeholder="Paste another base64 image here..."></textarea><br><br>

        <button type="submit">Save Ticket and Images</button>
    </form>
</body>
</html>
