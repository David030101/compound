CREATE TABLE my_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    number1 INT NOT NULL,
    number2 INT NOT NULL,
    text_input VARCHAR(255) NOT NULL
);
