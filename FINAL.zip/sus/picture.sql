CREATE TABLE images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_data LONGBLOB,
    image_name VARCHAR(255) NOT NULL
);
