<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>PMI</title>
  <style>
    .copyStatus {
      display: none;
      color: green;
      margin-left: 10px;
      font-weight: bold;
    }
    pre {
      background-color: #f4f4f4;
      padding: 10px;
      border: 1px solid #ccc;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
    button {
      margin-left: 10px;
    }
  </style>
  <script>
    function escapeHtml(unsafe) {
      return unsafe.replace(/[&<>"'`=\/]/g, function (match) {
        return '&#' + match.charCodeAt(0) + ';';
      });
    }

    function extractFirstSentence(text) {
      const sentenceRegex = /^.*?[.!?](?=\s+[A-Z]|$)/s;
      const match = text.match(sentenceRegex);
      return match ? match[0].trim() : text.trim();
    }

    let savedWeeklyDose = "";
    let savedDoseAndInstructions = "";
    let savedPharmacyInfo = "";

    function extractInformation() {
      const rawText = document.getElementById("inputText").value;
      const text = escapeHtml(rawText);

      // Extract Weekly Dose
      const weeklyDose = text.match(/Weekly Dose\n([^\n]*)/);
      const drugAdminMethod = text.match(/Drug Administration Method\n([^\n]*)/);
      const instructionsMatch = text.match(/INJECTION\n([\s\S]*?)\nPharmacy/);

      let cleanedInstructions = "Not found";
      if (instructionsMatch) {
        let instrText = instructionsMatch[1].replace(/Instructions:?/i, "").trim();
        cleanedInstructions = extractFirstSentence(instrText);
      }

      const doseAndInstructions = (weeklyDose && cleanedInstructions !== "Not found") ? 
        `${weeklyDose[1]} - ${cleanedInstructions}` : "Not found";

      // Save values for copying
      savedWeeklyDose = weeklyDose ? weeklyDose[1] : "";
      savedDoseAndInstructions = doseAndInstructions;

      // Display on page
      document.getElementById("weeklyDose").innerText = savedWeeklyDose || "Not found";
      document.getElementById("weeklyDoseAndInstructions").innerText = doseAndInstructions;
      document.getElementById("drugAdminMethod").innerText = drugAdminMethod ? drugAdminMethod[1] : "Not found";

      // Extract Pharmacy Information including "Compounding"
      const pharmacySection = text.match(/Pharmacy Information([\s\S]*?)\s*(?=Medication|$)/);
      savedPharmacyInfo = pharmacySection ? pharmacySection[1].trim() : "";

      // Display pharmacy information
      document.getElementById("pharmacyInfo").innerHTML = savedPharmacyInfo
        ? `<pre>${savedPharmacyInfo}</pre>`
        : "Not found";
    }

    function copyToClipboard(text, statusElementId) {
      if (!text) return;
      navigator.clipboard.writeText(text).then(() => {
        const copyStatus = document.getElementById(statusElementId);
        copyStatus.style.display = "inline";
        setTimeout(() => copyStatus.style.display = "none", 2000);
      }).catch(err => {
        alert("Failed to copy text: " + err);
      });
    }

    function copyWeeklyDose() {
      copyToClipboard(savedWeeklyDose, "copyStatusDose");
    }

    function copyDoseAndInstructions() {
      copyToClipboard(savedDoseAndInstructions, "copyStatusInstructions");
    }

    function copyPharmacyInfo() {
      copyToClipboard(savedPharmacyInfo, "copyStatusPharmacy");
    }
  </script>
</head>
<body>
  <h3>Extracted Patient Medication Instructions:</h3>

  <p>
    <strong>Weekly Dose:</strong>
    <span id="weeklyDose">Not found</span>
    <button onclick="copyWeeklyDose()">Copy</button>
    <span id="copyStatusDose" class="copyStatus">✅ Copied!</span>
  </p>

  <p>
    <strong>Weekly Dose and Instructions:</strong>
    <span id="weeklyDoseAndInstructions">Not found</span>
    <button onclick="copyDoseAndInstructions()">Copy</button>
    <span id="copyStatusInstructions" class="copyStatus">✅ Copied!</span>
  </p>

  <p><strong>Drug Administration Method:</strong> <span id="drugAdminMethod">Not found</span></p>

  <h3>Pharmacy Information:</h3>

  <p>
    <strong>Pharmacy Information:</strong>
    <span id="pharmacyInfo">Not found</span>
    <button onclick="copyPharmacyInfo()">Copy</button>
    <span id="copyStatusPharmacy" class="copyStatus">✅ Copied!</span>
  </p>

  <h2>PMI</h2>

  <label for="inputText">Paste the text here:</label><br />
  <textarea id="inputText" rows="15" cols="80"></textarea><br /><br />

  <button onclick="extractInformation()">Extract Information</button>
</body>
</html>
