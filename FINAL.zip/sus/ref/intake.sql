CREATE TABLE intake_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference_code VARCHAR(7) NOT NULL UNIQUE,
    first_name VARCHAR(100),

    injections_completed INT,
    last_dose_timing TEXT,
    medical_history_changed TEXT,
    opiate_use TEXT,
    bariatric_surgery TEXT,
    allergy_changes TEXT,
    medication_changes TEXT,
    current_weight FLOAT,
    weight_change TEXT,
    side_effects TEXT,
    blood_pressure TEXT,
    heart_rate TEXT,
    doctor_note TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
