<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Encounter Form</title>
</head>
<body>
    <h2>Patient Encounter Form</h2>
    <form action="" method="POST">
        <!-- Personal Information -->
        <label for="name">Patient Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="age">Age:</label>
        <input type="number" id="age" name="age" required><br><br>

        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" name="dob" required><br><br>

        <label for="gender">Gender:</label>
        <select id="gender" name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br><br>

        <!-- Medical History -->
        <label for="med_history">Medical History:</label><br>
        <textarea id="med_history" name="med_history" rows="4" cols="50" required></textarea><br><br>

        <label for="allergies">Known Allergies:</label><br>
        <textarea id="allergies" name="allergies" rows="2" cols="50"></textarea><br><br>

        <!-- Medication History -->
        <label for="current_medications">Current Medications:</label><br>
        <textarea id="current_medications" name="current_medications" rows="4" cols="50"></textarea><br><br>

        <!-- Weight Management -->
        <label for="weight">Current Weight:</label>
        <input type="number" id="weight" name="weight" required><br><br>

        <label for="height">Height:</label>
        <input type="number" id="height" name="height" required><br><br>

        <label for="goal_weight">Goal Weight:</label>
        <input type="number" id="goal_weight" name="goal_weight" required><br><br>

        <!-- Follow-up Instructions -->
        <label for="follow_up">Follow-up Instructions:</label><br>
        <textarea id="follow_up" name="follow_up" rows="4" cols="50"></textarea><br><br>

        <!-- Submit Form -->
        <button type="submit" name="submit">Submit Encounter</button>
    </form>

    <?php
    // Handling the form submission
    if (isset($_POST['submit'])) {
        // Collect and sanitize form data
        $name = htmlspecialchars($_POST['name']);
        $age = htmlspecialchars($_POST['age']);
        $dob = htmlspecialchars($_POST['dob']);
        $gender = htmlspecialchars($_POST['gender']);
        $med_history = htmlspecialchars($_POST['med_history']);
        $allergies = htmlspecialchars($_POST['allergies']);
        $current_medications = htmlspecialchars($_POST['current_medications']);
        $weight = htmlspecialchars($_POST['weight']);
        $height = htmlspecialchars($_POST['height']);
        $goal_weight = htmlspecialchars($_POST['goal_weight']);
        $follow_up = htmlspecialchars($_POST['follow_up']);

        // Calculate BMI (Body Mass Index)
        $bmi = ($weight / (($height / 100) * ($height / 100))); // Weight in kg and height in meters
        $bmi_status = '';
        if ($bmi < 18.5) {
            $bmi_status = 'Underweight';
        } elseif ($bmi >= 18.5 && $bmi < 24.9) {
            $bmi_status = 'Normal weight';
        } elseif ($bmi >= 25 && $bmi < 29.9) {
            $bmi_status = 'Overweight';
        } else {
            $bmi_status = 'Obese';
        }

        // Displaying the collected data
        echo "<h3>Encounter Summary</h3>";
        echo "<p><strong>Patient Name:</strong> $name</p>";
        echo "<p><strong>Age:</strong> $age</p>";
        echo "<p><strong>Date of Birth:</strong> $dob</p>";
        echo "<p><strong>Gender:</strong> $gender</p>";
        echo "<p><strong>Medical History:</strong><br> $med_history</p>";
        echo "<p><strong>Known Allergies:</strong><br> $allergies</p>";
        echo "<p><strong>Current Medications:</strong><br> $current_medications</p>";
        echo "<p><strong>Current Weight:</strong> $weight kg</p>";
        echo "<p><strong>Height:</strong> $height cm</p>";
        echo "<p><strong>Goal Weight:</strong> $goal_weight kg</p>";
        echo "<p><strong>Follow-up Instructions:</strong><br> $follow_up</p>";
        echo "<p><strong>BMI:</strong> " . round($bmi, 2) . " ($bmi_status)</p>";
    }
    ?>
</body>
</html>
