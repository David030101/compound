<?php
$intakeText = $_POST['intakeText'] ?? '';

$questions = [
    "How many injections of the current level of medication have you completed?",
    "When was your last dose of medication?",
    "Have there been any changes to your medical, social, or surgical history since your last visit with us?",
    "Do any of the following apply to you?",
    "Are you currently taking, plan to take, or have recently (within the last 3 months) taken opiate pain medications and/or opiate-based street drugs?",
    "Have you had bariatric (weight loss) surgery?",
    "Do any of the following currently or recently apply to you?",
    "Have there been any changes to your allergies since your last visit with us?",
    "Have there been any changes to your medications since your last visit with us?",
    "What is your current weight in pounds (lbs)?",
    "How much weight have you lost or gained since your last visit?",
    "Have you experienced any of the following since starting your medication? Please select all that apply.",
    "Have you experienced any of the following since starting your medication?",
    "What is your current or average blood pressure range?",
    "What is your current or average resting heart rate range?",
    "Do you have any further information which you would like the doctor to know?"
];

function cleanAnswer($answer) {
    $remove = [
        "This question is required before further medication can be prescribed.",
        "Please do not include urgent or emergent medical information here, as this is not reviewed immediately. For questions contact Support."
    ];
    foreach ($remove as $r) {
        $answer = str_ireplace($r, "", $answer);
    }
    return trim($answer);
}

function extractAnswer($question, $text) {
    $pos = stripos($text, $question);
    if ($pos === false) return null;
    $after = substr($text, $pos + strlen($question));
    $lines = preg_split("/\r\n|\n|\r/", $after);
    foreach ($lines as $line) {
        $line = cleanAnswer($line);
        if ($line !== "") {
            if (in_array(strtolower($line), ["no", "none of the above"])) return null;
            return $line;
        }
    }
    return null;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>INITIAL INTAKE</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            max-width: 900px;
            margin: auto;
            background: #f8f9fa;
        }
        textarea {
            width: 100%;
            height: 200px;
            padding: 12px;
            font-family: monospace;
            font-size: 14px;
        }
        button {
            margin-top: 10px;
            padding: 10px 16px;
            font-size: 14px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        h2 {
            margin-top: 30px;
        }
        pre {
            background: #f0f0f0;
            padding: 12px;
            white-space: pre-wrap;
            border-left: 5px solid #3498db;
            border-radius: 4px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background: #fff;
            padding: 10px 14px;
            margin: 6px 0;
            border-left: 4px solid #3498db;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .highlight {
            background-color: #fff9c4;
            border-left-color: #facc15;
        }
        .copy-btn {
            margin-left: 10px;
            background: #facc15;
            border: none;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<?php if (!empty($intakeText)): ?>
   
   <h2>Summary Output</h2>
   <ul>
       <?php foreach ($questions as $question):
           $answer = extractAnswer($question, $intakeText);
           if ($answer):
               $highlight = stripos($question, "further information") !== false;
       ?>
           <li class="<?php echo $highlight ? 'highlight' : ''; ?>">
               <strong><?php echo htmlspecialchars($question); ?></strong><br>
               <span class="answer-text"><?php echo htmlspecialchars($answer); ?></span>
               <?php if ($highlight): ?>
                   <button class="copy-btn" onclick="copyToClipboard(this)">Copy</button>
               <?php endif; ?>
           </li>
       <?php endif; endforeach; ?>
   </ul>
<?php endif; ?>
    <h1>Intake iNITIAL FOR REFILL</h1>

    <form method="post">
        <label for="intakeText">Paste your intake text here:</label><br>
        <textarea name="intakeText" id="intakeText"><?php echo htmlspecialchars($intakeText); ?></textarea><br>
        <button type="submit">Process</button>
    </form>


    <script>
        function copyToClipboard(btn) {
            const text = btn.parentElement.querySelector(".answer-text").innerText;
            navigator.clipboard.writeText(text).then(() => {
                btn.innerText = "Copied!";
                setTimeout(() => btn.innerText = "Copy", 1500);
            });
        }
    </script>
</body>
</html>
