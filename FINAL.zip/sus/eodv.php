<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eod";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle move to trash request
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["move_to_trash"])) {
    $id = $_POST["id"];
    
    // Move record to trash table
    $move_to_trash_sql = "INSERT INTO trash (id, number1, number2, text_input)
                          SELECT id, number1, number2, text_input FROM my_table WHERE id = ?";
    $stmt = $conn->prepare($move_to_trash_sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        // After moving to trash, delete from the original table
        $delete_sql = "DELETE FROM my_table WHERE id = ?";
        $stmt_delete = $conn->prepare($delete_sql);
        $stmt_delete->bind_param("i", $id);
        $stmt_delete->execute();
        
        $message = "<div class='success-message'>Record moved to trash successfully.</div>";
    } else {
        $message = "<div class='error-message'>Error moving record to trash: " . $conn->error . "</div>";
    }
    $stmt->close();
}

// Handle restore from trash
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["restore"])) {
    $id = $_POST["id"];
    
    // Restore record from trash table to original table
    $restore_sql = "INSERT INTO my_table (id, number1, number2, text_input)
                    SELECT id, number1, number2, text_input FROM trash WHERE id = ?";
    $stmt = $conn->prepare($restore_sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        // After restoring, delete from the trash table
        $delete_trash_sql = "DELETE FROM trash WHERE id = ?";
        $stmt_delete_trash = $conn->prepare($delete_trash_sql);
        $stmt_delete_trash->bind_param("i", $id);
        $stmt_delete_trash->execute();
        
        $message = "<div class='success-message'>Record restored successfully.</div>";
    } else {
        $message = "<div class='error-message'>Error restoring record: " . $conn->error . "</div>";
    }
    $stmt->close();
}

// Retrieve active records
$sql = "SELECT * FROM my_table";
$result = $conn->query($sql);

// Retrieve records in trash
$trash_sql = "SELECT * FROM trash";
$trash_result = $conn->query($trash_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Copy Each Value Separately</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        button {
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        .success-message {
            color: green;
        }

        .error-message {
            color: red;
        }

        .hidden {
            display: none;
        }

        .copy-button {
            margin: 2px;
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

    </style>
    <script>
        // Function to copy data to clipboard using Clipboard API
        function copyToClipboard(id, field) {
            const input = document.getElementById(field + '-' + id);
            const range = document.createRange();
            range.selectNode(input);
            window.getSelection().addRange(range);

            // Try using the Clipboard API to copy
            try {
                const successful = document.execCommand('copy');
                if (successful) {
                    // Optionally show a small success message (no popup alert)
                    console.log(`${field} copied!`);
                } else {
                    console.log(`Failed to copy ${field}`);
                }
            } catch (err) {
                console.error('Unable to copy using execCommand:', err);
            }

            // Clean up the selection
            window.getSelection().removeAllRanges();
        }

        // Function to copy all fields of a record to clipboard
        function copyAllFields(id) {
            const fields = ['num1', 'num2', 'text'];
            fields.forEach(function(field) {
                copyToClipboard(id, field);
            });
        }
    </script>
</head>
<body>

<h2>Inserted Data</h2>

<!-- Display success/error message -->
<?php if (!empty($message)) echo $message; ?>

<!-- Data Table (Non-deleted records) -->
<h3>Active Records</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Number 1</th>
        <th>Number 2</th>
        <th>Text Input</th>
        <th>Copy</th>
        <th>Move to Trash</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row["id"];
            echo "<tr>";
            echo "<td>$id</td>";
            echo "<td>{$row["number1"]}</td>";
            echo "<td>{$row["number2"]}</td>";
            echo "<td>{$row["text_input"]}</td>";
            echo "<td>
                    <button class='copy-button' onclick='copyToClipboard($id, \"num1\")'>Copy Number 1</button>
                    <button class='copy-button' onclick='copyToClipboard($id, \"num2\")'>Copy Number 2</button>
                    <button class='copy-button' onclick='copyToClipboard($id, \"text\")'>Copy Text</button>
                    <textarea id='num1-$id' class='hidden'>{$row["number1"]}</textarea>
                    <textarea id='num2-$id' class='hidden'>{$row["number2"]}</textarea>
                    <textarea id='text-$id' class='hidden'>{$row["text_input"]}</textarea>
                    <button class='copy-button' onclick='copyAllFields($id)'>Copy All</button>
                  </td>";
            echo "<td>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='id' value='$id'>
                        <button type='submit' name='move_to_trash'>Move to Trash</button>
                    </form>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No active records</td></tr>";
    }
    ?>
</table>

<!-- Trash Table -->
<h3>Trash</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Number 1</th>
        <th>Number 2</th>
        <th>Text Input</th>
        <th>Restore</th>
    </tr>

    <?php
    if ($trash_result->num_rows > 0) {
        while ($row = $trash_result->fetch_assoc()) {
            $id = $row["id"];
            echo "<tr>";
            echo "<td>$id</td>";
            echo "<td>{$row["number1"]}</td>";
            echo "<td>{$row["number2"]}</td>";
            echo "<td>{$row["text_input"]}</td>";
            echo "<td>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='id' value='$id'>
                        <button type='submit' name='restore'>Restore</button>
                    </form>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No records in trash</td></tr>";
    }
    ?>
</table>

</body>
</html>

<?php
$conn->close();
?>
