<?php
// Database connection
$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "image_search_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the 'id' parameter exists in the URL
if (isset($_GET['id'])) {
    $imageId = $_GET['id'];

    // SQL query to retrieve the image by ID
    $sql = "SELECT image_data FROM images WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $imageId);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($imageData);
    
    // If image is found
    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        // Base64 encode the image
        $imageSrc = "data:image/jpeg;base64," . base64_encode($imageData);
    } else {
        echo "Image not found.";
        exit;
    }

    $stmt->close();
} else {
    echo "No image ID provided.";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full-Screen Image</title>
    <style>
        /* Full-screen style */
        body {
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: black;
            overflow: hidden;
        }

        /* Container for image with scroll */
        .image-container {
            position: relative;
            width: 100%;
            height: 100%;
            overflow: auto; /* Enables scrolling when the image is larger than the viewport */
        }

        img {
            width: 100%;
            height: auto;
            display: block;
            object-fit: contain; /* Maintains the aspect ratio of the image */
        }

        /* Close button style */
        .close-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 30px;
            color: white;
            cursor: pointer;
            z-index: 9999;
        }
    </style>
</head>
<body>
    <span class="close-btn" onclick="window.close()">×</span> <!-- Close button to close the full-screen view -->
    <div class="image-container">
        <img src="<?php echo $imageSrc; ?>" alt="Full-Screen Image">
    </div>
</body>
</html>
