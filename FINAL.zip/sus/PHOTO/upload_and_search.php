<?php
// Database connection
$servername = "localhost"; // change this to your server name
$username = "root"; // change this to your MySQL username
$password = ""; // change this to your MySQL password
$dbname = "image_search_db"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    // Get the pasted image and search number
    $imageData = isset($_POST['imageData']) ? $_POST['imageData'] : null;
    $searchNumber = isset($_POST['searchNumber']) ? $_POST['searchNumber'] : null;

    // Validate search number
    if (!preg_match('/^\d{8}$/', $searchNumber)) {
        echo "Invalid search number. Please enter a 5-digit number.";
        exit();
    }

    // Validate the image (check if it's in base64 format)
    if (preg_match('/^data:image\/(jpeg|png|gif);base64,/', $imageData)) {
        // Clean the base64 data to remove metadata part
        $imageData = preg_replace('/^data:image\/(jpeg|png|gif);base64,/', '', $imageData);
        $imageData = base64_decode($imageData); // Decode the base64 string

        // Insert into the database
        $stmt = $conn->prepare("INSERT INTO images (search_number, image_data) VALUES (?, ?)");
        $stmt->bind_param("is", $searchNumber, $imageData);

        if ($stmt->execute()) {
            echo "Image uploaded successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid image data. Please paste a valid image.";
    }
}

$conn->close();
?>
