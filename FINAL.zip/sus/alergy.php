<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G-Plans WM Intake Parser</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 700px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            background: white;
        }
        textarea {
            width: 100%;
            height: 300px;
            font-size: 16px;
            padding: 10px;
            margin-bottom: 10px;
            resize: none;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .output {
            margin-top: 20px;
            font-size: 16px;
            color: black;
            text-align: left;
        }
        .warning {
            color: red;
            font-weight: bold;
        }
        .med-allergy-warning {
            color: red;
            font-weight: bold;
        }
        .address-warning {
            color: red;
            font-weight: bold;
        }
        .note {
            color: blue;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>G-Plans WM Intake Parser</h2>
    <p>Paste the intake information below to parse the data:</p>

    <!-- Textarea to paste the block of text -->
    <textarea id="inputText" placeholder="Paste the intake information here..."></textarea><br>
    
    <button id="parseButton" onclick="parseText()">Generate Output</button>

    <!-- Output section -->
    <div id="output" class="output"></div>
</div>

<script>
    function parseText() {
        const inputText = document.getElementById('inputText').value;

        // Regular expressions to extract values from the pasted text
        const regex = {
            dob: /Date of Birth\s*(\d{4}-\d{2}-\d{2})/,
            address1: /Address\s*Line 1\s*(.*)/,
            address2: /Line 2\s*(.*)/,
            state: /State\s*(\w{2})/,
            city: /City\s*(\w+)/,
            country: /Country\s*(\w+)/,
            zip: /Zip\s*(\d{5})/,
            bmi: /BMI\s*(\d+\.\d)/,
            height_ft: /Height \(ft.\)\s*(\d+)/,
            height_in: /Height \(in.\)\s*(\d+)/,
            weight: /Weight \(lbs.\)\s*(\d+)/,
            goal_weight: /Goal weight\.\s*(\d+)/,
            phone: /Phone\s*(\+?\d+)/,
            gender: /Gender\s*(\w+)/,
            medication_allergies: /Do you have any medication allergies\?\s*(Yes|No)/,
            medication_allergy_list: /If yes, list your medication allergies\.\s*(.*)/,
            weight_loss_medication: /Have you taken any prescription medications to lose weight before\?\s*(Yes|No)/,
            bariatric_surgery: /Have you had bariatric \(weight loss\) surgery before\?\s*(Yes|No)/,
            previous_weight_loss_attempt: /Have you ever attempted to lose weight in a weight management program\s*\?\s*(Yes|No)/,
            physical_activity: /Are you willing to:\s*Increase your physical activity/,
            caloric_intake: /Reduce your caloric intake/,
            weight_change: /How has your weight changed in the last 12 months\?\s*(.*)/,
            diabetes: /Have you been diagnosed with prediabetes or type 2 diabetes\?\s*(Yes|No)/,
            blood_pressure: /What is your current or average blood pressure range\?\s*(.*)/,
            heart_rate: /What is your current or average resting heart rate range\?\s*(.*)/,
            shipping_address: /Please list shipping address \(No PO boxes\)\s*(.*)/,
        };

        // Extracting values using regex
        const extracted = {};
        for (let key in regex) {
            const match = inputText.match(regex[key]);
            extracted[key] = match ? match[1] : 'Not provided';
        }

        // Generate the output
        let output = ` 
            <h3>Parsed Data</h3>
            <p><strong>BMI:</strong> ${extracted.bmi}</p>
            <p><strong>Goal Weight:</strong> ${extracted.goal_weight}</p>
            <p><strong>Shipping Address:</strong> ${extracted.shipping_address}</p>
        `;

        // Check if PO Box or PO Boxes are present in shipping address (case-insensitive)
        const address = extracted.shipping_address.toLowerCase();
        if (address.includes("po box") || address.includes("po boxes")) {
            output += ` 
                <div class="address-warning">
                    <strong>Warning:</strong> PO Box detected in the shipping address. Please note:
                    <ul>
                        <li>Sent to Tier 2</li>
                        <li>Copy ticket number</li>
                        <li>Unassign</li>
                    </ul>
                </div>
            `;
        }

        // Address and Shipping Address mismatch warning
        const fullAddress = `${extracted.address1}, ${extracted.address2}, ${extracted.city}, ${extracted.state}, ${extracted.country} ${extracted.zip}`.toLowerCase();
        if (fullAddress !== extracted.shipping_address.toLowerCase()) {
            output += `
                <div class="address-warning">
                    <strong>Warning:</strong> The Address and Shipping Address do not match!
                </div>
            `;
        }
        
        // Handling Medication Allergies
        if (extracted.medication_allergies === 'Yes') {
            if (extracted.medication_allergy_list && extracted.medication_allergy_list !== 'Not provided') {
                // If allergy details are provided, append them to the provider's note
                output += ` 
                    <p class="med-allergy-warning"><strong>Medication Allergies:</strong> ${extracted.medication_allergy_list}</p>
                    <p class="note"><strong>For Provider's note:</strong> Patient has listed the following allergies: ${extracted.medication_allergy_list}</p>
                `;
            } else {
                // If allergy details are blank, add the appropriate note
                output += ` 
                    <p class="med-allergy-warning"><strong>Medication Allergies:</strong> Yes, but no allergies listed.</p>
                    <p class="note"><strong>For Provider's note:</strong> Patient said 'Yes' on having medication allergies but did not list them on intake.</p>
                `;
            }
        } else {
            output += `<p><strong>Medication Allergies:</strong> No allergies reported.</p>`;
        }

        // Handling Weight Loss Medication Question
        if (extracted.weight_loss_medication === 'Yes') {
            output += `<p><strong>Weight Loss Medication:</strong> Yes</p>`;
            output += `<p class="note"><strong>For Provider's note:</strong> Patient has taken prescription medications to lose weight before.</p>`;
        } else {
            output += `<p><strong>Weight Loss Medication:</strong> No action required</p>`;
        }

        // Check for GLP1 medication or mention in the entire input text
        if (inputText.toLowerCase().includes("glp1")) {
            output += `<p class="note"><strong>Note:</strong> GLP1 medication detected in the intake information.</p>`;
        }

        // Display output
        document.getElementById('output').innerHTML = output;

        // Change button to redirect to DOSESPOT.PHP
        const parseButton = document.getElementById('parseButton');
        parseButton.innerHTML = 'Go to DOSESPOT.PHP';
        parseButton.onclick = function() {
            window.location.href = 'DOSESPOT.PHP'; // Redirect to DOSESPOT.PHP
        };
    }
</script>
<!-- Begin: Modular Checklist Component -->
<?php $uniqueId = uniqid('checklist_'); ?>

<style>
    /* Scoped styling */
    .checklist-container {
        width: 100%;
        max-width: 400px;
        margin: 40px auto;
        padding: 20px;
        border: 1px solid #ddd;
        background-color: #f9f9f9;
        border-radius: 8px;
        font-family: Arial, sans-serif;
    }

    .checklist-container h3 {
        margin-bottom: 10px;
        color: #333;
    }

    .checklist-container label {
        display: block;
        margin: 5px 0;
    }

    .checklist-container .checklist-section {
        display: none;
        margin-top: 15px;
        padding: 10px;
        border: 1px solid #ccc;
        background-color: #fff;
        border-radius: 6px;
    }

    .checklist-container select,
    .checklist-container input[type="checkbox"] {
        margin-top: 5px;
    }
</style>

<script>
    function toggleChecklistModule(uniqueId) {
        const selectEl = document.getElementById("checklist-type-" + uniqueId);
        const initial = document.getElementById("checklist-initial-" + uniqueId);
        const refill = document.getElementById("checklist-refill-" + uniqueId);

        if (selectEl.value === "initial") {
            initial.style.display = "block";
            refill.style.display = "none";
        } else if (selectEl.value === "refill") {
            refill.style.display = "block";
            initial.style.display = "none";
        } else {
            initial.style.display = "none";
            refill.style.display = "none";
        }
    }
</script>

<div class="checklist-container">
    <h3>Checklist</h3>

    <label for="checklist-type-<?= $uniqueId ?>">Select Type:</label>
    <select id="checklist-type-<?= $uniqueId ?>" name="type" onchange="toggleChecklistModule('<?= $uniqueId ?>')" required>
        <option value="">-- Choose --</option>
        <option value="initial">Initial</option>
        <option value="refill">Refill</option>
    </select>

    <!-- Initial Checklist Section -->
    <div id="checklist-initial-<?= $uniqueId ?>" class="checklist-section">
        <strong>Initial Checklist:</strong>
        <label><input type="checkbox" name="correct_date_<?= $uniqueId ?>"> Correct Date</label>
        <label><input type="checkbox" name="cma_<?= $uniqueId ?>"> CMA</label>
        <label><input type="checkbox" name="med_dose_spot_<?= $uniqueId ?>"> Medicine in Dose Spot</label>
        <label><input type="checkbox" name="meds_intake_<?= $uniqueId ?>"> Meds in Intake</label>
        <label><input type="checkbox" name="hpi_section_<?= $uniqueId ?>"> HPI Section Completed</label>
        <label><input type="checkbox" name="medical_section_select_<?= $uniqueId ?>"> Medical Section Selected</label>
        <label><input type="checkbox" name="medical_section_input_<?= $uniqueId ?>"> Medical Section Input Filled</label>
    </div>

    <!-- Refill Checklist Section -->
    <div id="checklist-refill-<?= $uniqueId ?>" class="checklist-section">
        <strong>Refill Checklist:</strong>
        <label><input type="checkbox" name="last_deliver_<?= $uniqueId ?>"> Check Last Delivery</label>
        <label><input type="checkbox" name="intake_refill_<?= $uniqueId ?>"> Check Intake Refill</label>
        <label><input type="checkbox" name="cma_appt_<?= $uniqueId ?>"> Check CMA in Appointment Date</label>
        <label><input type="checkbox" name="dose_spot_<?= $uniqueId ?>"> Check Dose Spot</label>
        <label><input type="checkbox" name="current_weight_<?= $uniqueId ?>"> Check Current Weight</label>
        <label><input type="checkbox" name="prev_weight_<?= $uniqueId ?>"> Check Previous Weight</label>
        <label><input type="checkbox" name="labs_<?= $uniqueId ?>"> Check Labs</label>
        <label><input type="checkbox" name="requested_meds_<?= $uniqueId ?>"> Requested Meds</label>
    </div>

    <br>
    <button type="submit">Submit Checklist</button>
</div>
<!-- End: Modular Checklist Component -->

</body>
</html>
