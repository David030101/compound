<?php
// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'eod';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle trash request
if (isset($_GET['trash_id'])) {
    $id = (int)$_GET['trash_id'];

    // Copy to trash
    $stmt = $conn->prepare("INSERT INTO trash (number1, number2, text_input) SELECT number1, number2, text_input FROM my_table WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    // Delete from my_table
    $stmt = $conn->prepare("DELETE FROM my_table WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php");
    exit;
}

// Fetch data from the table
$result = $conn->query("SELECT * FROM my_table");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copy All Fields Separately</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        .copy-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .copy-btn:hover { background-color: #2980b9; }
        .trash-button {
            background-color: #e74c3c;
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
        }
        .trash-button:hover { background-color: #c0392b; }
    </style>
</head>
<body>

<h2>My Table</h2>

<?php if ($result->num_rows > 0): ?>
<table>
    <tr>
        <th>ID</th>
        <th>Number 1</th>
        <th>Number 2</th>
        <th>Text Input</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['number1']) ?></td>
        <td><?= htmlspecialchars($row['number2']) ?></td>
        <td><?= htmlspecialchars($row['text_input']) ?></td>
        <td><?= htmlspecialchars($row['status_text']) ?></td>
        <td>
            <button class="copy-btn" onclick="copyFieldsSeparately('<?= htmlspecialchars($row['number1']) ?>', '<?= htmlspecialchars($row['number2']) ?>', '<?= htmlspecialchars($row['text_input']) ?>')">Copy All Separately</button>
            <!-- No confirmation pop-up anymore -->
            <a class="trash-button" href="?trash_id=<?= $row['id'] ?>">Trash</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php else: ?>
<p>No records found.</p>
<?php endif; ?>

<script>
function copyFieldsSeparately(number1, number2, textInput) {
    // Create a temporary textarea to hold each copy operation
    const tempInput = document.createElement("textarea");

    // Copy Number 1 separately
    tempInput.value = number1;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
    alert("Copied Number 1: " + number1);

    // Copy Number 2 separately
    tempInput.value = number2;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
    alert("Copied Number 2: " + number2);

    // Copy Text Input separately
    tempInput.value = textInput;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
    alert("Copied Text Input: " + textInput);
}
</script>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
