<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>INITIAL INTAKE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Roboto', sans-serif;
      padding: 20px;
    }
    button {
      padding: 15px 30px;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      margin: 10px;
      transition: background-color 0.3s ease;
    }
    button:nth-of-type(1) { background-color: #0984e3; }
    button:nth-of-type(1):hover { background-color: #74b9ff; }
    button:nth-of-type(2) { background-color: #d63031; }
    button:nth-of-type(2):hover { background-color: #ff7675; }
    button:nth-of-type(3) { background-color: #00b894; }
    button:nth-of-type(3):hover { background-color: #55efc4; }
    button:nth-of-type(4) { background-color: #6c5ce7; }
    button:nth-of-type(4):hover { background-color: #a29bfe; }
    button:nth-of-type(5) { background-color: #e17055; }
    button:nth-of-type(5):hover { background-color: #fab1a0; }
    button:nth-of-type(6) { background-color: #fdcb6e; color: #2d3436; }
    button:nth-of-type(6):hover { background-color: #ffeaa7; }
    input {
      padding: 10px;
      font-size: 16px;
      margin-left: 10px;
      width: 80px;
    }
    .note {
      font-style: italic;
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>INITIAL INTAKE</h1>
    <button onclick="openTabs()">Open All Tabs</button>
    <button onclick="closeTabs()">Close All Tabs</button>
    <button onclick="goToPHP()">GO TO REFILL</button>
    <button onclick="toggleEOD()">EOD Form</button>
    <button onclick="goToeod()">GO TO eod</button>
    <button onclick="goToALL()">GO TO GLP1</button>

    <p class="note">Make sure pop-ups are allowed in your browser.</p>

    <p>
      <label for="minutes">How many minutes until redirect?</label>
      <input type="number" id="minutes" value="5" min="1" max="60">
      <button onclick="startCountdown()">Start Countdown</button>
      <button onclick="toggleCountdown()">Toggle Countdown</button>
    </p>
    <p id="countdown">Next redirect in: 00:00</p>
  </div>

  <script>
    let openedTabs = [];
    let eodTab = null;
    let countdownInterval = null;
    let countdownEndTime = null;
    let isCounting = false;

    const countdownDisplay = document.getElementById("countdown");

    function updateCountdown() {
      const now = new Date().getTime();
      const remaining = countdownEndTime - now;

      if (remaining <= 0) {
        clearInterval(countdownInterval);
        localStorage.removeItem("countdownEndTime");
        localStorage.removeItem("countdownRunning");
        countdownDisplay.textContent = "Redirecting...";
        window.location.href = "https://www.nextvas-yogurt.com/";
        return;
      }

      const minutes = Math.floor(remaining / 1000 / 60);
      const seconds = Math.floor((remaining / 1000) % 60);
      countdownDisplay.textContent = `Next redirect in: ${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }

    function startCountdown() {
      const userMinutes = parseInt(document.getElementById("minutes").value);
      if (isNaN(userMinutes) || userMinutes <= 0) {
        alert("Please enter a valid number of minutes.");
        return;
      }

      const now = new Date().getTime();
      countdownEndTime = now + userMinutes * 60 * 1000;
      localStorage.setItem("countdownEndTime", countdownEndTime);
      localStorage.setItem("countdownRunning", "true");

      clearInterval(countdownInterval);
      isCounting = true;
      countdownInterval = setInterval(updateCountdown, 1000);
      updateCountdown();
    }

    function toggleCountdown() {
      if (isCounting) {
        clearInterval(countdownInterval);
        isCounting = false;
        localStorage.setItem("countdownRunning", "false");
      } else {
        countdownEndTime = parseInt(localStorage.getItem("countdownEndTime"));
        if (isNaN(countdownEndTime)) return;
        countdownInterval = setInterval(updateCountdown, 1000);
        isCounting = true;
        localStorage.setItem("countdownRunning", "true");
      }
    }

    window.onload = function () {
      closeTabs();
      clearClipboard();

      const savedEndTime = localStorage.getItem("countdownEndTime");
      const running = localStorage.getItem("countdownRunning") === "true";

      if (savedEndTime && running) {
        countdownEndTime = parseInt(savedEndTime);
        isCounting = true;
        countdownInterval = setInterval(updateCountdown, 1000);
        updateCountdown();
      } else if (savedEndTime) {
        countdownEndTime = parseInt(savedEndTime);
        updateCountdown(); // Just show it once even if paused
      }
    };

    async function clearClipboard() {
      try {
        await navigator.clipboard.writeText('');
        console.log('Clipboard cleared!');
      } catch (err) {
        console.error('Failed to clear clipboard: ', err);
      }
    }

    function openTabs() {
      const urls = [
        "http:/sus/ref/intake.php",
                "https://https://www.nextvas-yogurt.com/",
                "http://localhost/SUS/DOSE.php",
                "http://localhost/SUS/ip1.php",
                "http:/sus/ref/med.php"
      ];
      closeTabs();
      urls.forEach(url => {
        const win = window.open(url, '_blank');
        if (win) {
          openedTabs.push(win);
        } else {
          alert("Some popups may have been blocked. Please allow popups for this site.");
        }
      });
    }

    function closeTabs() {
      openedTabs.forEach(tab => {
        if (tab && !tab.closed) {
          tab.close();
        }
      });
      openedTabs = [];
      if (eodTab && !eodTab.closed) {
        eodTab.close();
        eodTab = null;
      }
    }

    function goToPHP() {
      window.location.href = 'r.php';
    }

    function toggleEOD() {
      if (eodTab && !eodTab.closed) {
        eodTab.close();
        eodTab = null;
      } else {
        eodTab = window.open("https://docs.google.com/forms/d/e/1FAIpQLSe3XeKa8jQRgcWxpvH8Ktv90dDCKhBToj2CcrDPIXQTCLvB0g/viewform", '_blank');
        if (!eodTab) {
          alert("Popup for EOD Form is blocked. Please allow popups.");
        }
      }
    }

    function goToeod() {
      window.location.href = 'eodS.php';
    }

    function goToALL() {
      window.location.href = 'ALERGY.php';
    }
  </script>
</body>
</html>
