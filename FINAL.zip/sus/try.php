<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>boom</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f4f7fa;
      margin: 0;
      padding: 0;
      color: #333;
    }

    h2 {
      text-align: center;
      color: #007bff;
      margin-top: 20px;
    }

    .form-container {
      max-width: 1000px;
      margin: 20px auto;
      background-color: #ffffff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    textarea {
      width: 100%;
      height: 180px;
      padding: 10px;
      font-size: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
      resize: vertical;
    }

    button {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      margin-top: 15px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }

    .result-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      font-size: 15px;
    }

    .result-table th, .result-table td {
      text-align: left;
      padding: 8px;
      border-bottom: 1px solid #ddd;
      vertical-align: top;
    }

    .result-table th {
      background-color: #f0f4f8;
      color: #007bff;
      width: 30%;
    }

    .blue-answer {
      color: #007bff;
      font-weight: bold;
    }

    .green-answer {
      color: #28a745;
      font-weight: bold;
    }

    .note {
      margin-top: 10px;
      font-weight: bold;
      color: #d9534f;
    }

    .warning {
      color: red;
      font-weight: bold;
      margin: 10px 0;
    }

    .go-to-button {
      text-align: center;
      margin-top: 20px;
    }

    .go-to-button a {
      display: inline-block;
      padding: 10px 20px;
      background-color: #28a745;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }

    .go-to-button a:hover {
      background-color: #218838;
    }

    .copy-btn {
      margin-top: 5px;
      padding: 4px 8px;
      font-size: 13px;
      background-color: #ffc107;
      color: black;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .copy-btn:hover {
      background-color: #e0a800;
    }

    @media (max-width: 768px) {
      .result-table th, .result-table td {
        font-size: 14px;
        padding: 6px;
      }

      textarea {
        height: 140px;
      }
    }
  </style>
  <script>
    function copyToClipboard(id) {
      const text = document.getElementById(id).innerText;
      navigator.clipboard.writeText(text).then(() => {
        // Show a custom message instead of an alert
        showCustomMessage("Copied to clipboard!");
      });
    }

    // Function to display a custom message
    function showCustomMessage(message) {
      const messageBox = document.createElement('div');
      messageBox.innerText = message;
      messageBox.style.position = 'fixed';
      messageBox.style.top = '20px';
      messageBox.style.right = '20px';
      messageBox.style.backgroundColor = '#28a745';
      messageBox.style.color = 'white';
      messageBox.style.padding = '10px 20px';
      messageBox.style.borderRadius = '5px';
      messageBox.style.zIndex = '1000';
      document.body.appendChild(messageBox);

      // Automatically hide the message after 2 seconds
      setTimeout(() => {
        messageBox.remove();
      }, 2000);
    }
  </script>
</head>
<body>

  <h2>G-Plans Intake Extractor</h2>

  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $text = $_POST["rawText"];
      $lines = preg_split("/\r\n|\n|\r/", trim($text));
      $results = [];

      $questions = [
          "Medication Requested" => "Medication the patient wants?",
          "Weight" => "Weight (lbs.)",
          "BMI" => "BMI",
          "Goal Weight" => "Goal weight.",
          "Currently Taking Weight Loss Meds" => "Are you currently taking medication(s) for weight loss?",
          "Currently Taking Other Meds" => "Are you currently taking any medications or supplements (over-the-counter prescription)?",
          "Medication Allergies" => "Do you have any medication allergies?",
          "Bariatric Surgery" => "Have you had bariatric (weight loss) surgery before?",
          "Do Any Apply?" => "Do any of the following apply to you?",
          "Currently Apply" => "Do any of the following currently or recently apply to you?",
          "Blood Pressure" => "What is your current or average blood pressure range?",
          "Heart Rate" => "What is your current or average resting heart rate range?"
      ];

      $specialIfYesKeep = [
          "If yes, please include name, dose, and frequency of all your medications, including prescriptions, OTC, and supplements",
          "If yes, list your medication allergies."
      ];

      $poBoxDetected = false;
      foreach ($lines as $line) {
          if (
              stripos($line, "po box") !== false &&
              stripos($line, "Shipping Address (No PO boxes)") === false
          ) {
              $poBoxDetected = true;
              break;
          }
      }

      for ($i = 0; $i < count($lines); $i++) {
          $line = trim($lines[$i]);

          foreach ($questions as $label => $trigger) {
              if (stripos($line, $trigger) !== false && !isset($results[$label])) {

                  if ($label == "Currently Apply") {
                      $answers = [];
                      for ($j = $i + 1; $j < count($lines); $j++) {
                          $nextLine = trim($lines[$j]);
                          if ($nextLine === "" || preg_match('/\?$/', $nextLine)) break;
                          $answers[] = $nextLine;
                      }
                      $results[$label] = implode("<br>", $answers);
                      continue;
                  }

                  $answer = isset($lines[$i + 1]) ? trim($lines[$i + 1]) : "Not found";

                  if (strtolower($answer) === "yes") {
                      $detail = '';
                      for ($j = $i + 2; $j < count($lines); $j++) {
                          $nextLine = trim($lines[$j]);
                          if (in_array($nextLine, $specialIfYesKeep)) {
                              $detail = $lines[$j + 1] ?? "No further details";
                              break;
                          }
                          if (!empty($nextLine) && stripos($nextLine, "If yes") === false) {
                              $detail = $nextLine;
                              break;
                          }
                      }
                      $results[$label] = $detail;
                  } elseif (strtolower($answer) !== "no") {
                      $results[$label] = $answer;
                  }
              }
          }
      }

      echo '<div class="form-container">';

      if ($poBoxDetected) {
          echo "<div class='warning'>⚠️ Warning: PO Box detected. Please enter a valid physical shipping address.</div>";
      }

      if (stripos($text, "glp1") !== false) {
          echo "<div class='note'>Note: GLP1 medication mentioned in intake.</div>";
      }

      if (!empty($results)) {
          echo "<table class='result-table'>";
          echo "<tr><th>Field</th><th>Response</th></tr>";
          foreach ($results as $q => $a) {
              $class = '';
              $id = str_replace(' ', '_', strtolower($q));
              if ($q == "Currently Taking Other Meds") $class = 'blue-answer';
              if ($q == "Medication Allergies") $class = 'green-answer';

              echo "<tr><td>$q</td><td class='$class'><div id='$id'>$a</div>";

              // Add copy buttons for selected fields
              if (in_array($q, ["Currently Taking Other Meds", "Medication Allergies", "Currently Apply"])) {
                  echo "<button class='copy-btn' onclick=\"copyToClipboard('$id')\">Copy</button>";
              }

              echo "</td></tr>";
          }
          echo "</table>";
      }

      echo '<div class="go-to-button"><a href="index.php">new</a></div>';
      echo '</div>';

  } else {
      echo '
      <div class="form-container">
        <form method="post">
          <textarea name="rawText" placeholder="Paste here..." required></textarea>
          <button type="submit">Extract Answers</button>
        </form>
      </div>';
  }
  ?>

</body>
</html>
