<?php
// Database connection settings
$host = "localhost";
$user = "root"; // Change as needed
$pass = "";     // Change as needed
$dbname = "gplans"; // Your DB name

// Create DB connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve parsed data from POST
if (isset($_POST['parsedData'])) {
    $data = json_decode($_POST['parsedData'], true);

    // Prepare statement
    $stmt = $conn->prepare("INSERT INTO parsed_intakes (
        dob, bmi, goal_weight, shipping_address, medication_allergies,
        medication_allergy_list, weight_loss_medication
    ) VALUES (?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "sdsssss",
        $data['dob'],
        $data['bmi'],
        $data['goal_weight'],
        $data['shipping_address'],
        $data['medication_allergies'],
        $data['medication_allergy_list'],
        $data['weight_loss_medication']
    );

    if ($stmt->execute()) {
        echo "<h3>Data stored successfully in MySQL!</h3>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No data received.";
}

$conn->close();
?>
