<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refill Visit with Refill Intake</title>
</head>
<body>

<h2>Refill Visit Details</h2>

<?php
// Sample patient data for Refill Visit
$patientDataRefill = array(
    'medicationDose' => 0.5,  // Example dosage in mg
    'medicationName' => 'Tirzepatide',  // Example medication name
    'lastInjectionDate' => '2025-03-31',  // Last injection date (change as needed)
    'numInjections' => 3  // Number of injections on current dose
);

// Set the duration in weeks to 0 (as requested)
$durationWeeks = 0;  // Force the duration to show as 0 weeks

// Set "Last Dose" range to always be "0-5 days"
$lastDoseRange = '0-5 days'; // Always display "0-5 days" for last injection range

// Customizing the output message based on the requested format
$refillVisitDetails = "
    The patient is currently on {$patientDataRefill['medicationDose']} mg of {$patientDataRefill['medicationName']} for the last {$durationWeeks} weeks and has taken {$patientDataRefill['numInjections']} injections on the current dose.<br><br>
    Date of last injection: {$lastDoseRange}<br><br>
    How many injections has the patient taken on the current dose: {$patientDataRefill['numInjections']}
";
?>

<!-- Displaying the Refill Visit Information -->
<h3>Refill Visit</h3>
<p><?php echo $refillVisitDetails; ?></p>

<!-- Refill Intake Form with Text Box (where you can paste data) -->
<h3>Enter Refill Intake Notes</h3>
<form method="post" action="">
    <label for="refillIntake">Refill Intake:</label><br>
    <textarea name="refillIntake" id="refillIntake" rows="12" cols="80" placeholder="Paste your refill intake notes here..."></textarea><br><br>

    <!-- Submit Button -->
    <input type="submit" value="Submit">
</form>

<?php
// PHP code to handle the form submission (if needed)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data from the form
    $refillIntake = htmlspecialchars($_POST['refillIntake']);

    // Check if data is entered and do not display it
    if (!empty($refillIntake)) {
        // You can choose to process or save the data here if needed
        // Just do not output it here anymore
    } else {
        echo "<p>No Refill Intake entered.</p>";
    }
}
?>

</body>
</html>
