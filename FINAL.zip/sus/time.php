<!DOCTYPE html>
<html>
<head>
    <title>Appointment Gap Analyzer</title>
</head>
<body>
    <h2>Appointment Gap Analyzer</h2>
    <form method="post">
        <label for="appointmentText">Paste your appointment text below:</label><br><br>
        <textarea name="appointmentText" id="appointmentText" rows="12" cols="100" required><?php 
            echo isset($_POST['appointmentText']) ? htmlspecialchars($_POST['appointmentText']) : '';
        ?></textarea><br><br>
        <input type="submit" value="Analyze">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $text = $_POST['appointmentText'];

        // Extract appointment durations
        preg_match_all('/(\d+)\s+minutes/', $text, $durations);
        $durations = $durations[1];

        // Extract appointment times
        preg_match_all('/On (.+? at .+? [AP]M) CDT/', $text, $times_raw);
        $times_raw = $times_raw[1];

        // Convert to DateTime objects
        $times = array_map(function($time) {
            return DateTime::createFromFormat('M d, Y at g:i A', $time);
        }, $times_raw);

        if (count($times) >= 2) {
            // Check gaps between all consecutive appointments
            for ($i = 0; $i < count($times) - 1; $i++) {
                $gap = $times[$i + 1]->getTimestamp() - $times[$i]->getTimestamp();
                $gap_minutes = $gap / 60;

                echo "<p>Gap between appointment " . ($i + 1) . " and " . ($i + 2) . ": <strong>{$gap_minutes} minutes</strong></p>";

                if ($gap_minutes > 20) {
                    echo "<div style='color: red; font-weight: bold;'>⚠️ Warning: Appointment gap exceeds 20 minutes!</div>";
                } else {
                    echo "<div style='color: green;'>✅ Appointment gap is within acceptable range.</div>";
                }
                echo "<hr>";
            }
        } else {
            echo "<p style='color: orange;'>Please provide at least 2 appointment entries with proper formatting (e.g., 'On Apr 19, 2025 at 7:30 AM CDT').</p>";
        }
    }
    ?>
</body>
</html>
